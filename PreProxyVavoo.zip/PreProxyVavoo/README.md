---
title: Turktv
emoji: 😻
colorFrom: pink
colorTo: yellow
sdk: docker
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
